AT90USB1287.hex - includes both bootloader and application section - for use with JTAG
Xplain_USB.a90  - includes only application section - for use with Flip