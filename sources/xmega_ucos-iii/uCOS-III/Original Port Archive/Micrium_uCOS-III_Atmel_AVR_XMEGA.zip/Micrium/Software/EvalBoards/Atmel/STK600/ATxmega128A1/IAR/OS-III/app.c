/*
*********************************************************************************************************
*                                              EXAMPLE CODE
*
*                          (c) Copyright 2003-2008; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                             EXAMPLE CODE
*
*                                           Atmel  Xmega 128A1
*                                                on the
*                                         STK600 development kit
*
* Filename      : app.c
* Version       : V1.00
* Programmer(s) : FT
*********************************************************************************************************
*/

/*
**************************************************************************************************************
*                                               INCLUDE FILES
**************************************************************************************************************
*/

#include  <includes.h>


/*
**************************************************************************************************************
*                                               VARIABLES
**************************************************************************************************************
*/

static  CPU_STK        AppTaskStartStk[APP_TASK_START_STK_SIZE];

static  OS_TCB         AppTaskStartTCB;

/*
**************************************************************************************************************
*                                           FUNCTION PROTOTYPES
**************************************************************************************************************
*/

static  void          AppTaskCreate           (void);
static  void          AppTaskStart            (void  *p_arg);

/*
**************************************************************************************************************
*                                                MAIN
**************************************************************************************************************
*/

void  main (void)
{
    OS_ERR  err;

    CPU_IntDis();
                                                                /* IMPORTANT: MUST be setup before calling 'OSInit()'        */
    OSTaskStkSize     = OS_CFG_IDLE_TASK_STK_SIZE;              /* Setup the default stack size                              */
    OSTaskStkSizeHard = OS_TASK_STK_SIZE_HARD;                  /* Setup the default hardware stack size                     */

    OSInit(&err);                                               /* Initialize "uC/OS-III, The Real-Time Kernel"              */
    
    OSTaskCreate((OS_TCB     *)&AppTaskStartTCB,                /* Create the start task                                     */
                 (CPU_CHAR   *)"App Task Start",
                 (OS_TASK_PTR )AppTaskStart,
                 (void       *)0,
                 (OS_PRIO     )APP_TASK_START_PRIO,
                 (CPU_STK    *)&AppTaskStartStk[0],
                 (CPU_STK_SIZE)APP_TASK_START_STK_SIZE_LIMIT,
                 (CPU_STK_SIZE)APP_TASK_START_STK_SIZE,
                 (OS_MSG_QTY  )0,
                 (OS_TICK     )0,
                 (void       *)0,
                 (OS_OPT     )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR    *)&err);
    
    
    OSStart(&err);                                              /* Start multitasking (i.e. give control to uC/OS-III)       */
}


/*
*********************************************************************************************************
*                                          AppTaskStart()
*
* Description : This is an example of a startup task.  As mentioned in the book's text, you MUST
*               initialize the ticker only once multitasking has started.
*
* Arguments   : p_arg   is the argument passed to 'AppTaskStart()' by 'OSTaskCreate()'.
*
* Return(s)   : none.
*
* Caller(s)   : This is a Task.
*
* Note(s)    : 1) The first line of code is used to prevent a compiler warning because 'p_arg' is not
*                 used.  The compiler should not generate any code for this statement.
*********************************************************************************************************
*/

static void  AppTaskStart (void *p_arg)
{
    CPU_INT08U  i;
    OS_ERR      err;


    (void)p_arg;                                                /* Prevent compiler warnings                                */

    BSP_Init();                                                 /* Initialize BSP functions                                 */
    CPU_Init();                                                 /* Initialize the uC/CPU services                           */

#if (OS_CFG_STAT_TASK_EN > 0)
    OSStatTaskCPUUsageInit (&err);                              /* Determine CPU capacity                                   */
#endif
    
    AppTaskCreate();                                            /* Create the application tasks                             */

    while (DEF_TRUE) {                                          /* Task body, always written as an infinite loop.           */
        for (i = 1; i < 8; i++) {
            LED_On(i);
            OSTimeDlyHMSM(0, 0, 0, 100,
                          OS_OPT_TIME_HMSM_STRICT,
                         &err);
            LED_Off(i);
            OSTimeDlyHMSM(0, 0, 0, 100,
                          OS_OPT_TIME_HMSM_STRICT,
                         &err);
        }
        for (i = 1; i < 8; i++) {
            LED_On(9 - i);
            OSTimeDlyHMSM(0, 0, 0, 100,
                          OS_OPT_TIME_HMSM_STRICT,
                         &err);
            LED_Off(9 - i);
            OSTimeDlyHMSM(0, 0, 0, 100,
                          OS_OPT_TIME_HMSM_STRICT,
                         &err);
        }
    }
}

/*
**************************************************************************************************************
*                                           AppTaskCreate()
*
* Description : This function creates the application tasks.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : AppTaskStart()
*
* Note(s)     : none.
*                 
**************************************************************************************************************
*/

static  void  AppTaskCreate (void)
{
}
	 	 			 		    	 				  	 		  	 	 	 		 	  	  	  	 	  	  	 	  	  	 					 	   	 	 	  	  			 	  	 		   		 		   		 		 	  	 		 	    		  			 		   	 			 					 	 	     	  		 	 	  	  	 	 					 	    		 	 	 		  	 	 	   	 			   	 	     	 					 	  	  		      		  	   		      		      		  			 		      		  	  			  
